angular.module('app.services', [])

.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}])

// .service('FiltService', function() {
//   return {
//     filts:
//       {
//         clubs: '',
//         counties: '',
//         countries: '',
//         time: '',
//         events: '',
//         leagues: '',
//         ages: '',
//         gender: ''
//       },
//     getFilts: function() {
//       return this.filts
//     },
//     setFilts: function(filters) {
//       for (var key in filters) {
//       	this.filts[key] = filters[key];
//       }
//     }

//   }
// });

